//exportaciones 
export { Api_key };
export { urlApi };
export { urlPrinc };
export { urlNews };
export { urlPrincNews };
export { urlApiFilter };
export { urlRecentWord};
export {urlRecentWord2};
export { ApiKey2 };
export { urlNewsSearch };

//variables de el apartado del world covid
const Api_key = '2fe3ddb6b2msh21d7a5ccde171f7p1eb1cfjsnccde2f6eb561';
const ApiKey2 = '/jUcvJ9H+gWTqyrV8iOI0g==WcFlVRQDleZC0NFV'
const urlApi = 'https://vaccovid-coronavirus-vaccine-and-treatment-tracker.p.rapidapi.com/api/npm-covid-data/world';
const urlPrinc = 'vaccovid-coronavirus-vaccine-and-treatment-tracker.p.rapidapi.com';

//variable de las last covid countries
const urlPrincNews ='free-news.p.rapidapi.com';
const urlNews = 'https://free-news.p.rapidapi.com/v1/search?q=covid&lang=en';

//filter covid
const urlApiFilter = 'https://vaccovid-coronavirus-vaccine-and-treatment-tracker.p.rapidapi.com/api/npm-covid-data/';

//recent word 

const urlRecentWord2 = 'word-of-the-day2.p.rapidapi.com';
const urlRecentWord = 'https://word-of-the-day2.p.rapidapi.com/word/dc/recent';

//noticas buscar
const urlNewsSearch = 'https://free-news.p.rapidapi.com/v1/search?q=&lang=en';